BEBA ÁGUA — ANDROID

O aplicativo agenda alarmes/notificações locais do Android.
Funções:
- Intervalos de 15, 30, 45, 60, 90 e 120 minutos.
- Horário de início e fim.
- Quantidade de água por lembrete.
- Som de alarme e vibração.
- Continua agendado com o app fechado.
- Reagenda após reiniciar o celular.
- Botão de teste em 5 segundos.

IMPORTANTE:
Este pacote é o PROJETO-FONTE. Para instalar no celular é necessário gerar um APK.
O ambiente usado para criar este projeto não possui o Android SDK/Gradle completo e, por isso, o APK não pôde ser compilado localmente.

Foi incluído o arquivo .github/workflows/build-apk.yml, que permite ao GitHub Actions compilar o APK na nuvem.
