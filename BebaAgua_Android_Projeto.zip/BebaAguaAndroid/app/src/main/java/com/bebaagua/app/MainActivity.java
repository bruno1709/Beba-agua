package com.bebaagua.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;

import java.util.Locale;

public class MainActivity extends Activity {
    private Spinner intervalSpinner, amountSpinner;
    private TimePicker startPicker, endPicker;
    private TextView status;
    private Switch enabledSwitch;

    private final int[] intervals = {15,30,45,60,90,120};
    private final int[] amounts = {150,200,250,300,350,500};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUI();
        loadPrefs();
        requestNotificationPermissionIfNeeded();
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(28));
        root.setBackgroundColor(Color.rgb(247,250,252));
        scroll.addView(root);

        TextView title = text("💧 Beba água", 28, true);
        root.addView(title);
        TextView subtitle = text("Lembretes para manter sua hidratação em dia", 15, false);
        subtitle.setTextColor(Color.DKGRAY);
        root.addView(subtitle, marginBottom(22));

        root.addView(label("Lembrar a cada"));
        intervalSpinner = new Spinner(this);
        String[] intervalLabels = {"15 minutos","30 minutos","45 minutos","1 hora","1 hora e 30 min","2 horas"};
        intervalSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, intervalLabels));
        root.addView(intervalSpinner, marginBottom(16));

        root.addView(label("Começar às"));
        startPicker = new TimePicker(this);
        startPicker.setIs24HourView(true);
        root.addView(startPicker, marginBottom(14));

        root.addView(label("Parar às"));
        endPicker = new TimePicker(this);
        endPicker.setIs24HourView(true);
        root.addView(endPicker, marginBottom(14));

        root.addView(label("Quantidade por lembrete"));
        amountSpinner = new Spinner(this);
        String[] amountLabels = {"150 ml","200 ml","250 ml","300 ml","350 ml","500 ml"};
        amountSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, amountLabels));
        root.addView(amountSpinner, marginBottom(18));

        enabledSwitch = new Switch(this);
        enabledSwitch.setText("Ativar lembretes");
        enabledSwitch.setTextSize(18);
        root.addView(enabledSwitch, marginBottom(14));

        Button save = new Button(this);
        save.setText("Salvar e ativar");
        save.setTextSize(17);
        save.setOnClickListener(v -> saveAndSchedule());
        root.addView(save, marginBottom(10));

        Button test = new Button(this);
        test.setText("Testar alarme em 5 segundos");
        test.setOnClickListener(v -> testAlarm());
        root.addView(test, marginBottom(10));

        Button exact = new Button(this);
        exact.setText("Permitir alarmes precisos");
        exact.setOnClickListener(v -> requestExactAlarmPermission());
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) exact.setVisibility(Button.GONE);
        root.addView(exact, marginBottom(12));

        status = text("", 14, false);
        status.setTextColor(Color.rgb(30,100,60));
        root.addView(status);

        TextView note = text("O lembrete usa o sistema de alarmes/notificações do Android e continua funcionando com o aplicativo fechado. Em alguns aparelhos, o modo de economia de bateria pode atrasar notificações.", 13, false);
        note.setTextColor(Color.GRAY);
        root.addView(note, marginTop(18));

        setContentView(scroll);
    }

    private void saveAndSchedule() {
        int startH = startPicker.getHour(), startM = startPicker.getMinute();
        int endH = endPicker.getHour(), endM = endPicker.getMinute();
        if ((endH * 60 + endM) <= (startH * 60 + startM)) {
            Toast.makeText(this, "O horário final deve ser depois do inicial.", Toast.LENGTH_LONG).show();
            return;
        }

        boolean enabled = enabledSwitch.isChecked();
        int interval = intervals[intervalSpinner.getSelectedItemPosition()];
        int amount = amounts[amountSpinner.getSelectedItemPosition()];

        getSharedPreferences(ReminderScheduler.PREFS, MODE_PRIVATE).edit()
                .putBoolean(ReminderScheduler.ENABLED, enabled)
                .putInt(ReminderScheduler.INTERVAL, interval)
                .putInt(ReminderScheduler.START_H, startH)
                .putInt(ReminderScheduler.START_M, startM)
                .putInt(ReminderScheduler.END_H, endH)
                .putInt(ReminderScheduler.END_M, endM)
                .putInt(ReminderScheduler.AMOUNT, amount)
                .apply();

        if (enabled) {
            ReminderScheduler.cancel(this);
            ReminderScheduler.scheduleNext(this, true);
            status.setText("✓ Lembretes ativados a cada " + interval + " minutos.");
        } else {
            ReminderScheduler.cancel(this);
            status.setText("Lembretes desativados.");
        }
    }

    private void loadPrefs() {
        var p = getSharedPreferences(ReminderScheduler.PREFS, MODE_PRIVATE);
        int interval = p.getInt(ReminderScheduler.INTERVAL, 60);
        int amount = p.getInt(ReminderScheduler.AMOUNT, 250);
        intervalSpinner.setSelection(indexOf(intervals, interval));
        amountSpinner.setSelection(indexOf(amounts, amount));
        startPicker.setHour(p.getInt(ReminderScheduler.START_H, 8));
        startPicker.setMinute(p.getInt(ReminderScheduler.START_M, 0));
        endPicker.setHour(p.getInt(ReminderScheduler.END_H, 22));
        endPicker.setMinute(p.getInt(ReminderScheduler.END_M, 0));
        enabledSwitch.setChecked(p.getBoolean(ReminderScheduler.ENABLED, false));
    }

    private void testAlarm() {
        getSharedPreferences(ReminderScheduler.PREFS, MODE_PRIVATE).edit()
                .putBoolean(ReminderScheduler.ENABLED, true)
                .putInt(ReminderScheduler.AMOUNT, amounts[amountSpinner.getSelectedItemPosition()])
                .apply();

        android.app.AlarmManager am = (android.app.AlarmManager)getSystemService(ALARM_SERVICE);
        Intent i = new Intent(this, ReminderReceiver.class);
        android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(this, 1001, i,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
        long trigger = System.currentTimeMillis() + 5000;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms())
                am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, trigger, pi);
            else
                am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, trigger, pi);
        } else {
            am.setExact(android.app.AlarmManager.RTC_WAKEUP, trigger, pi);
        }
        status.setText("Teste agendado para daqui a 5 segundos.");
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 200);
        }
    }

    private void requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(this, "Abra as configurações do app e permita alarmes e lembretes.", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Alarmes precisos já estão permitidos.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private int indexOf(int[] arr, int value) {
        for (int i=0;i<arr.length;i++) if (arr[i]==value) return i;
        return 0;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(30,41,59));
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }
    private TextView label(String s) {
        TextView t = text(s, 14, true);
        t.setPadding(0, dp(8), 0, dp(6));
        return t;
    }
    private LinearLayout.LayoutParams marginBottom(int dp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(dp); return p;
    }
    private LinearLayout.LayoutParams marginTop(int dp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(dp); return p;
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }
}
