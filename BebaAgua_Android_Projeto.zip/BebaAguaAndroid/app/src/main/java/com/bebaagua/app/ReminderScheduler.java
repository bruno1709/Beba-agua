package com.bebaagua.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

import java.util.Calendar;

public class ReminderScheduler {
    public static final String PREFS = "beba_agua_prefs";
    public static final String ENABLED = "enabled";
    public static final String INTERVAL = "interval";
    public static final String START_H = "start_h";
    public static final String START_M = "start_m";
    public static final String END_H = "end_h";
    public static final String END_M = "end_m";
    public static final String AMOUNT = "amount";

    public static void scheduleNext(Context context, boolean fromNow) {
        var prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(ENABLED, false)) return;

        int interval = prefs.getInt(INTERVAL, 60);
        int startH = prefs.getInt(START_H, 8);
        int startM = prefs.getInt(START_M, 0);
        int endH = prefs.getInt(END_H, 22);
        int endM = prefs.getInt(END_M, 0);

        Calendar now = Calendar.getInstance();
        Calendar next = (Calendar) now.clone();
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);

        Calendar start = (Calendar) now.clone();
        start.set(Calendar.HOUR_OF_DAY, startH);
        start.set(Calendar.MINUTE, startM);
        start.set(Calendar.SECOND, 0);
        start.set(Calendar.MILLISECOND, 0);

        Calendar end = (Calendar) now.clone();
        end.set(Calendar.HOUR_OF_DAY, endH);
        end.set(Calendar.MINUTE, endM);
        end.set(Calendar.SECOND, 0);
        end.set(Calendar.MILLISECOND, 0);

        if (now.before(start)) {
            next = start;
        } else if (now.after(end)) {
            start.add(Calendar.DAY_OF_YEAR, 1);
            next = start;
        } else {
            next.add(Calendar.MINUTE, fromNow ? interval : 1);
            if (next.after(end)) {
                start.add(Calendar.DAY_OF_YEAR, 1);
                next = start;
            }
        }

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 1001, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        long trigger = next.getTimeInMillis();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            }
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    public static void cancel(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, 1001, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        am.cancel(pi);
    }
}
